﻿using System.IO;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;

namespace SaberForge
{
    public class CompilePartBundleWindow : EditorWindow
    {
        // Adapted from the custom sabers exporter

        private PartBundleDescriptor[] partBundles;
    

        [MenuItem("Window/Part Exporter")]
        public static void ShowWindow()
        {
            EditorWindow.GetWindow(typeof(CompilePartBundleWindow), false, "Part Exporter");
        }

        void OnGUI()
        {
            GUILayout.Label("Part Bundles", EditorStyles.boldLabel);

            GUILayout.Space(20);

            foreach (PartBundleDescriptor partBundle in partBundles)
            {
                GUILayout.Label("Bundle : " + partBundle.gameObject.name, EditorStyles.boldLabel);
                partBundle.partBundleAuthor = EditorGUILayout.TextField("Author name", partBundle.partBundleAuthor);
                partBundle.partBundleName = EditorGUILayout.TextField("Saber name", partBundle.partBundleName);

                if (GUILayout.Button("Export " + partBundle.partBundleName))
                {
                    ExportPartBundle(partBundle);
                }

            }

        }

        public static void ExportPartBundle(PartBundleDescriptor partBundle)
        {
            GameObject partBundleObj = partBundle.gameObject;
            if (partBundleObj != null && partBundle != null)
            {
                string path = EditorUtility.SaveFilePanel("Save part bundle", "", partBundle.partBundleName + ".partbundle", "partbundle");
                Debug.Log(path == "");

                if (path != "")
                {
                    string fileName = Path.GetFileName(path);
                    string folderPath = Path.GetDirectoryName(path);

                    Selection.activeObject = partBundleObj;
                    EditorUtility.SetDirty(partBundle);
                    EditorSceneManager.MarkSceneDirty(partBundleObj.scene);
                    EditorSceneManager.SaveScene(partBundleObj.scene);
                    PrefabUtility.CreatePrefab("Assets/_PartBundle.prefab", Selection.activeObject as GameObject);
                    AssetBundleBuild assetBundleBuild = default(AssetBundleBuild);
                    assetBundleBuild.assetNames = new string[] {
                            "Assets/_PartBundle.prefab"
                        };

                    assetBundleBuild.assetBundleName = fileName;

                    BuildTargetGroup selectedBuildTargetGroup = EditorUserBuildSettings.selectedBuildTargetGroup;
                    BuildTarget activeBuildTarget = EditorUserBuildSettings.activeBuildTarget;

                    BuildPipeline.BuildAssetBundles(Application.temporaryCachePath, new AssetBundleBuild[] { assetBundleBuild }, 0, EditorUserBuildSettings.activeBuildTarget);
                    EditorPrefs.SetString("currentBuildingAssetBdundlePath", folderPath);
                    EditorUserBuildSettings.SwitchActiveBuildTarget(selectedBuildTargetGroup, activeBuildTarget);
                    AssetDatabase.DeleteAsset("Assets/_PartBundle.prefab");
                    File.Move(Application.temporaryCachePath + "/" + fileName, path);
                    AssetDatabase.Refresh();
                    EditorUtility.DisplayDialog("Exportisation Successful!", "Exportisation Successful!", "OK");
                }
                else
                {
                    EditorUtility.DisplayDialog("Exportisation Failed!", "Path is invalid.", "OK");
                }
            }
            else
            {
                EditorUtility.DisplayDialog("Exportisation Failed!", "Part bundle object missing.", "OK");
            }
        }


        private void OnFocus()
        {
            partBundles = GameObject.FindObjectsOfType<PartBundleDescriptor>();
        }

     
    }

}

